﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

// Starting in 2 seconds.
// a projectile will be launched every 0.3 seconds

public class TextBalance : MonoBehaviour
{
	public Text balanceText;
	public float UpdateTextTimeStep = 0.3f;
	void Start() {
		InvokeRepeating ("UpdateText", 0f, UpdateTextTimeStep);
	}
		
	void Update() {
		//balanceText.text =	balanceText.text = CoreNumbers.Balance.ToString();
	}

	void UpdateText() {
		balanceText.text =	balanceText.text = CoreNumbers.Balance.ToString();
	}
}
