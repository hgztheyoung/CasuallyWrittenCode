﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class TextState : MonoBehaviour {
	public Text incTextScript;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		incTextScript.text = "IncSpeed:" + CoreNumbers.IncreasePerStep.ToString () + '\n'
		+"IncPrice:" +  CoreNumbers.IncPrice.ToString ();
	}
}
