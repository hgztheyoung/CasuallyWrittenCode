﻿using UnityEngine;
using System.Collections;

public class GameController : MonoBehaviour
{
	public float UpdateTextTimeStep = 0.3f;
	// Use this for initialization
	void Start() {
		CoreNumbers.Balance = 0;
		CoreNumbers.IncreasePerStep = 1;
		CoreNumbers.IncPrice = 3;
		InvokeRepeating ("UpdateCoreNumbers", 0f, UpdateTextTimeStep);
	}
	
	// Update is called once per frame
	void UpdateCoreNumbers() {
		//CoreNumbers.Balance = CoreNumbers.calcNextBalance();
		CoreNumbers.updateBalance();
	}
}

