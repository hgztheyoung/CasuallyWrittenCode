﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
public class ButtonScript : MonoBehaviour {
	public Button increaseSpeedButton; 
	// Use this for initialization
	void Start () {
		increaseSpeedButton.onClick.AddListener(TaskOnClick);
	}
	
	// Update is called once per frame
	void Update () {
	    
	}

	void TaskOnClick() {
		CoreNumbers.doPayment ();
	}
}
