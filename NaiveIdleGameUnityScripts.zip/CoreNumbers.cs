﻿using UnityEngine;
using System.Collections;

public class CoreNumbers {
    public static long Balance;
    public static long IncreasePerStep;
	public static long IncPrice;

	public static long calcIncPrice(){
		long ret = Balance/2+IncPrice;
		return ret;
	}
	public static void updateIncPrice(){
		IncPrice = calcIncPrice ();
	}

	public static long calcInc(){
		long ret = (long)(IncreasePerStep * 1.03) + 10;
		return ret;
	}
	public static void updateInc(){
		IncreasePerStep = calcInc ();
	}

	public static long calcNextBalance(){
		long ret = Balance + IncreasePerStep;
		return ret;
	}

	public static void updateBalance(){
		Balance = calcNextBalance ();
	}
	public static void doPayment(){
		if (Balance > IncPrice) {
			Balance -= IncPrice;
			updateIncPrice ();
			updateInc ();
		}
	}
}
